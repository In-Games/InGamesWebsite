import sprites_load
import tkinter

info = tkinter.Tk()


def show(screen, zombie_anim_index, entity1x, entity2x, entity3x, entity4x, entity5x, entity6x, entity_type, meteor1y,
         meteor2y, meteor3y, meteor4y, meteor5y, missile1x, missile2x):
    if entity_type == "zombie":
        screen.blit(sprites_load.zombie_animations_left[zombie_anim_index % len(sprites_load.zombie_animations_left)],
                    (entity2x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.zombie_animations_right[zombie_anim_index % len(sprites_load.zombie_animations_left)],
                    (entity1x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.zombie_animations_left[zombie_anim_index % len(sprites_load.zombie_animations_left)],
                    (entity4x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.zombie_animations_right[zombie_anim_index % len(sprites_load.zombie_animations_left)],
                    (entity3x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.zombie_animations_left[zombie_anim_index % len(sprites_load.zombie_animations_left)],
                    (entity6x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.zombie_animations_right[zombie_anim_index % len(sprites_load.zombie_animations_left)],
                    (entity5x, info.winfo_screenheight() - 190))

    if entity_type == "dino":
        screen.blit(sprites_load.dino_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity2x, info.winfo_screenheight() - 250))

        screen.blit(sprites_load.dino_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity1x, info.winfo_screenheight() - 250))

        screen.blit(sprites_load.dino_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity4x, info.winfo_screenheight() - 250))

        screen.blit(sprites_load.dino_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity3x, info.winfo_screenheight() - 250))

        screen.blit(sprites_load.dino_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity6x, info.winfo_screenheight() - 250))

        screen.blit(sprites_load.dino_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity5x, info.winfo_screenheight() - 250))

    if entity_type == "orc":
        screen.blit(sprites_load.orc_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity2x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.orc_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity1x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.orc_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity4x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.orc_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity3x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.orc_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity6x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.orc_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity5x, info.winfo_screenheight() - 190))

    if entity_type == "knight":
        screen.blit(sprites_load.knight_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity2x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.knight_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity1x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.knight_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity4x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.knight_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity3x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.knight_animations_left[zombie_anim_index % len(sprites_load.dino_animations_left)],
                    (entity6x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.knight_animations_right[zombie_anim_index % len(sprites_load.dino_animations_right)],
                    (entity5x, info.winfo_screenheight() - 190))

    if entity_type == "boss1":
        screen.blit(sprites_load.boss1, (entity6x, info.winfo_screenheight() - 800))

        screen.blit(sprites_load.meteor, (entity1x, meteor1y))
        screen.blit(sprites_load.meteor, (entity2x, meteor2y))
        screen.blit(sprites_load.meteor, (entity3x, meteor3y))
        screen.blit(sprites_load.meteor, (entity4x, meteor4y))
        screen.blit(sprites_load.meteor, (entity5x, meteor5y))

    if entity_type == "demon":
        screen.blit(sprites_load.demon_animations_left[zombie_anim_index % len(sprites_load.demon_animations_left)],
                    (entity2x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.demon_animations_right[zombie_anim_index % len(sprites_load.demon_animations_left)],
                    (entity1x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.demon_animations_left[zombie_anim_index % len(sprites_load.demon_animations_left)],
                    (entity4x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.demon_animations_right[zombie_anim_index % len(sprites_load.demon_animations_left)],
                    (entity3x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.demon_animations_left[zombie_anim_index % len(sprites_load.demon_animations_left)],
                    (entity6x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.demon_animations_right[zombie_anim_index % len(sprites_load.demon_animations_left)],
                    (entity5x, info.winfo_screenheight() - 190))

    if entity_type == "jinn":
        screen.blit(sprites_load.jinn_animations_left[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity2x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.jinn_animations_right[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity1x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.jinn_animations_left[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity4x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.jinn_animations_right[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity3x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.jinn_animations_left[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity6x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.jinn_animations_right[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity5x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.missile_right, (missile2x, info.winfo_screenheight() - 70))

        screen.blit(sprites_load.missile_left, (missile1x, info.winfo_screenheight() - 70))

    if entity_type == "lizard":
        screen.blit(sprites_load.lizard_animations_left[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity2x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.lizard_animations_right[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity1x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.lizard_animations_left[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity4x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.lizard_animations_right[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity3x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.lizard_animations_left[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity6x, info.winfo_screenheight() - 190))

        screen.blit(sprites_load.lizard_animations_right[zombie_anim_index % len(sprites_load.jinn_animations_left)],
                    (entity5x, info.winfo_screenheight() - 190))
